<?php echo $__env->make('layout.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content">
    <?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="main">

            <div>
                <div class=" col-md-8 mx-auto">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="alert-danger">
                            <?php
                            $message = Session::get('Thongbao');
                            if($message){
                                echo '<span class="text-alert">'.$message.'</span>';
                                session::put('Thongbao',null);
                            }
                            ?>
                        </div>

                        <h2><a href="">Thêm danh mục sản phẩm</a></h2>

                        <form action="<?php echo e(route('add-category')); ?>" method="post" class="form-inline" role="form">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                            <div class="input-group" style="width: 100%">
                                <input name="category" type="text" placeholder="Tên danh mục">
                            </div>

                            <div class="input-group">
                                <button type="submit" class="btn">Thêm danh mục</button>
                            </div>

                        </form>
                </div>           
            </div>                  
        </div>                          

    </div>

<?php $__env->stopSection(); ?>
<style>

    .main h2 a {
        text-decoration: none;
    }
    .input-group input {
        width: 100%;
        height: 50px;
        font-size: 1.5rem;
        padding-left: 1rem;
        margin: 1.5rem 0;
    }
</style>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/category/create.blade.php ENDPATH**/ ?>