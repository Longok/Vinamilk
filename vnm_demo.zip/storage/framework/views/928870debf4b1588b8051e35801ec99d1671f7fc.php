<?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
   <div class="container">
       <div class="row">
           <div class="col-md-12">
            <section class="panel mt-3">
                <div class=" col-md-8 mx-auto">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="alert-danger">
                        <?php
                          $message = Session::get('Thongbao');
                          if($message){
                              echo '<span class="text-alert">'.$message.'</span>';
                              session::put('Thongbao',null);
                          }
                        ?>
                    </div>
                    <div class="mt-4">
                        <a href="">Thêm sản phẩm</a>
                    </div>
                        <form action="<?php echo e(Route('add-product')); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <div class="form-group mt-3">
                                    <label for="">Tên sản phẩm</label>
                                    <input class="form-control" name="name" type="text">
                                </div>
                                <div class="form-group mt-3">
                                    <label for="">Mô tả sản phẩm</label>
                                    <input class="form-control" name="description" type="text">
                                </div>
                                <div class="form-group mt-3">
                                    <label for="">Số lượng sản phẩm</label>
                                    <input class="form-control" name="quantity" type="text">
                                </div>
                                <div class="form-group mt-3">
                                    <label for="">Giá sản phẩm</label>
                                    <input class="form-control" name="price" type="text">
                                </div>
                                <div class="form-group">
                                    <label for="">Giảm giá sản phẩm</label>
                                    <select name="discount" class="form-control input-sm m-bot15">
                                        <option value="0">0%</option>
                                        <option value="10">10%</option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="50">50%</option>
                                    </select>
                                </div>
                                <div class="form-group mt-3">
                                    <label for="">Hình ảnh sản phẩm</label>
                                    <input class="form-control" name="image" type="file">
                                </div>
                                <div class="form-group mt-3">
                                    <label for="">Danh mục sản phẩm</label>
                                    <select name="category_id" class="form-control input-sm m-bot15">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                               </div>
                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-danger">Thêm sản phẩm</button>
                                </div>
                        </form>
                </div>
            </section>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/products/create.blade.php ENDPATH**/ ?>