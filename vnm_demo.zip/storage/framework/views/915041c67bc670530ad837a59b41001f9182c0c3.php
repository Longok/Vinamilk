<?php echo $__env->make('layout.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content">
    <?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="main">
            <div class="col-8 mx-auto">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="alert-danger">
                    <?php
                        $message = Session::get('Thongbao');
                        if($message){
                            echo '<span class="text-alert">'.$message.'</span>';
                            session::put('Thongbao',null);
                        }
                    ?>
                </div>
                <h2 class="mt-4">
                    <a href="">Thêm bài viết</a>
                </h2>
                    <form action="<?php echo e(URL::to('/add-news')); ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="form-group mt-3">
                                <label class="info">Tiêu đề</label>
                                <input class="form-control" name="title" type="text">
                            </div>
                            <div class="form-group mt-3">
                                <label class="info">Mô tả ngắn</label>
                                <input class="form-control" name="description" type="text">
                            </div>
                            <div class="form-group mt-3">
                                <label class="info">Nội dung</label>
                                <textarea type="text" class="form-control ckeditor" placeholder="Nội dung" name="content" ></textarea> 
                            </div>                              
                            <div class="form-group mt-3">
                                <label class="info">Hình ảnh bài viết</label>
                                <input class="form-control" name="image" type="file">
                            </div>
                            <div class="form-group mt-3">
                                <button type="submit" class="btn btn-danger">Thêm bài viết</button>
                            </div>
                    </form>
            </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<style>

    .main h2 a {
        text-decoration: none;
    }
    
    .form-group .info {
        font-size: 1.5rem;
    }

    select, option {
        font-size: 1.5rem;
    }
</style>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/news/create.blade.php ENDPATH**/ ?>