
<div class="header">
    <a href="<?php echo e(URL::to('/index')); ?>" class="logo">
        <img src="<?php echo e(asset('image/logo.png')); ?>" alt=""> <span>Demo</span> 
    </a>

    <nav class="navbar">
        <ul>
            <li>
                <a href="<?php echo e(URL::to('/index')); ?>">Trang chủ</a>
            </li>
            <li>
                <a href="#">Sản phẩm
                    <i class="ti-angle-down"></i>  
                </a>
                <ul class="submenu">
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(URL::to('/category/'.$category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="<?php echo e(URL::to('/news')); ?>">Tin tức</a></li>
            <li><a href="#">Liên hệ</a></li>                   
        </ul> 
    </nav>
   

    <div class="icons">
        <div class="icon-header fas fa-bars" id="menu-btn"></div>
        <div class="icon-header fas fa-search" id="search-btn"></div>
        <!-- <div class="icon-header fas fa-shopping-cart" id="cart-btn"> -->
            <!-- <span class="show-cart"></span> -->
            <a class="icon-header fas fa-shopping-cart" id="cart-btn" href="<?php echo e(URL::to('/cart')); ?>"><span class="show-cart"></span></a>   
        <!-- </div> -->
        
        <?php if(Auth::check()): ?>
            <?php echo e(Auth::user()->name); ?>

            <a class="logout" href ="<?php echo e(URL::to('/logout')); ?>">Đăng xuất</a>
        <?php else: ?>
        <a href="<?php echo e(URL::to('/login')); ?>">
            <div class="icon-header fas fa-user" id="login-btn"></div>
        </a> 
        <?php endif; ?>
    </div>

    <!-- search -->
    <form action="<?php echo e(URL::to('/search')); ?>" class="search-form" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="search" id="search-box"  name="keywords" placeholder="Tìm kiếm..." aria-label="Recipient's username">
        <label for="search-box" class="fas fa-search"></label>
    </form>

    <!-- login -->
    <!-- <form action="<?php echo e(URL::to('/login')); ?>" method="post" class="login-form">
        <?php echo e(csrf_field()); ?>  
        <h3>Đăng nhập</h3>
        <input type="email" placeholder="email" class="box">
        <input type="password" placeholder="password" class="box">
        <p>Chưa có tài khoản <a href="<?php echo e(URL::to('/sign-up')); ?>">Tạo ngay</a></p>
        <input type="submit" value="Đăng nhập" class="btn">
    </form> -->
</div>



<script>
    // search
    const searchForm = document.querySelector('.search-form');
    const searchBtn = document.querySelector('#search-btn');
    
    searchBtn.addEventListener('click', function(){
        searchForm.classList.toggle('active');
        navbar.classList.remove('active');
    });

    const navbar = document.querySelector('.navbar');
    const menuBtn = document.querySelector('#menu-btn');  

    menuBtn.addEventListener('click', function(){
        navbar.classList.toggle('active');
        searchForm.classList.remove('active');
    });

    // $(document).ready(function (){
    //     show_cart();
    //     function show_cart(){
    //         $.ajax({
    //             url:'<?php echo e(url('/show-cart')); ?>',
    //             method: "GET",
    //             success:function(data){
    //                 $('.show-cart').html(data);
    //             }
    //         });
    //     }    
    // });
    
</script>
<?php /**PATH D:\Project\vnm_demo\resources\views/layout/header.blade.php ENDPATH**/ ?>