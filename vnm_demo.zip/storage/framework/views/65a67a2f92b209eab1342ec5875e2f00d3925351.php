<div id="header">
    <div class="image-nav">
        <div class="image">
        <a href ="<?php echo e(URL::to('/')); ?>"><img src="<?php echo e(asset('image/logo.png')); ?>" height="70" width="120"></a>
            <div class="brand">
                <span>D</span>emo
            </div>
        </div>
        <div class="nav">
            <ul>
                <li><a href="<?php echo e(URL::to('/show-cart')); ?>">Giỏ hàng</a></li>
                <?php if(Auth::check()): ?>
                <li><a href="<?php echo e(URL::to('/check-out')); ?>">Thanh toán</a></li>
                <?php else: ?> 
                <li> <a href="<?php echo e(URL::to('/login')); ?>">Thanh toán</a></li>
                <?php endif; ?>

                <?php if(Auth::check()): ?>
                    <i class="fas fa-smile" style="color:blue"></i> <?php echo e(Auth::user()->name); ?>

                    <li><a href ="<?php echo e(URL::to('/logout')); ?>">Đăng Xuất</a></li>
                <?php else: ?>
                <li><a href ="<?php echo e(URL::to('/login')); ?>">Đăng nhập</a></li>
                <li><a href ="<?php echo e(URL::to('/sign-up')); ?>">Đăng ký</a></li>   
                <?php endif; ?>                      
            </ul>
        </div> 
    </div> 
        
</div>


<?php /**PATH D:\Project\vnm_demo\resources\views/layout/header.blade.php ENDPATH**/ ?>