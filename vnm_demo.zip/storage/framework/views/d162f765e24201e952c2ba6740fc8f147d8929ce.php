<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <div id="menu">
        <ul>
            <li class="active">
                <a href="<?php echo e(URL::to('/index')); ?>">Trang chủ</a>
            </li>
            <li>
                <a href="#">Sản phẩm
                    <i class="ti-angle-down"></i>  
                </a>
                <ul class="submenu">
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(URL::to('/category/'.$category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="#">Tin tức</a></li>
            <li><a href="#">Liên hệ</a></li>                   
        </ul> 
        <div class="search-btn">
            <form action="<?php echo e(URL::to('/search')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="keywords" placeholder="Tìm kiếm.." aria-label="Recipient's username">
                        <div class="input-group-append">
                            <span class="input-group-text"><i class="fa fa-search"></i></span>
                        </div>
                    </div>               
            </form>                        
        </div>
        <div id="menu-icon" class="menu-icon">
            <i class="ti-align-justify"></i>
        </div>      
    </div> 
    <div class="slide">
        <div id="demo" class="carousel " data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                    <li data-target="#demo" data-slide-to="1"></li>
                    <li data-target="#demo" data-slide-to="2"></li>
                </ul>
            <div class="carousel-inner">
                <?php
                $i = 0;
                ?>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $i++;
                ?>
                <div class="carousel-item <?php echo e($i == 1 ? 'active' :''); ?>">
                    <img src="<?php echo e(asset('/storage/image/'.$slide->image)); ?>" width="100%">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>    
    </div> 
    <div class="content">
        <div class="container">            
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="box col-lg-4 col-md-4 col-sm-6 col-xs-6 mt-2">
                    <form action="<?php echo e(Route('cart',$pro->id)); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="card">
                            <div class="card-image d-flex justify-content-around mt-2">
                                <img src="<?php echo e(asset('/storage/image/'.$pro->image)); ?>" height="160">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title "><?php echo e($pro->name); ?></h5>
                                <?php if($pro->price * $pro->discount == 0): ?>
                                <h6 class="card-title">Giá: <?php echo e(number_format($pro->price)); ?> VNĐ</h6>
                                <?php else: ?>
                                <strike class="card-title">Giá: <?php echo e(number_format($pro->price)); ?> vnđ</strike>
                                <h6 class="card-title">Giá: <?php echo e(number_format($pro->price - (( $pro->price *
                                    $pro->discount)/100))); ?> VNĐ</h6>
                                <?php endif; ?>
                            </div>
                            <div class="quantity">
                                <!-- <h6>Số lượng</h6> -->
                                <input class="input" name="qty" type="number" min="1" value="1">
                                <input name="productid_hidden" type="hidden" value="<?php echo e($pro->id); ?>">
                                <button type="submit" class="btn btn-primary mb-2">Mua hàng</button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <span class="pagination justify-content-center"><?php echo e($products->render()); ?></span>
        </div>     
    </div>           
</body>
<script>
    var menu = document.getElementById('menu');
    var menuIcon = document.getElementById('menu-icon');
    var menuHeight = menu.clientHeight;

        menuIcon.onclick = function () {
            var closeIcon = menu.clientHeight === menuHeight;
            if (closeIcon) {
                menu.style.height = 'auto';
            } else {
                menu.style.height = null;
            }
        }

</script>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views//index.blade.php ENDPATH**/ ?>