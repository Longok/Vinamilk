<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

    <div class="slide mb-5">

        <div id="demo" class="carousel " data-ride="carousel">
            <ul class="carousel-indicators">
                <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                <li data-target="#demo" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner">
                <?php
                $i = 0;
                ?>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $i++;
                ?>
                <div class="carousel-item <?php echo e($i == 1 ? 'active' :''); ?>">
                    <img src="<?php echo e(asset('/storage/image/'.$slide->image)); ?>" width="100%">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>  

    </div> 

    <section class="cards">   

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card__item">
                <form>
                <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($pro->id); ?>" class="product_id_<?php echo e($pro->id); ?>">
                    <input type="hidden" value="<?php echo e($pro->name); ?>" class="product_name_<?php echo e($pro->id); ?>">
                    <input type="hidden" value="<?php echo e($pro->image); ?>" class="product_image_<?php echo e($pro->id); ?>">

                    <?php if(!$pro->discount): ?>
                        <input type="hidden" value="<?php echo e($pro->price); ?>" class="product_price_<?php echo e($pro->id); ?>">
                    <?php else: ?>
                        <input type="hidden" value="<?php echo e($pro->price - $pro->price * $pro->discount/100); ?>" class="product_price_<?php echo e($pro->id); ?>">
                    <?php endif; ?>
                    <input id="quantity" type="hidden" min="1" value="1" class="product_quantity_<?php echo e($pro->id); ?>">        
                    <img class="card-image"src="<?php echo e(asset('/storage/image/'.$pro->image)); ?>">
                    <div class="card-content">
                        <div class="card__top">
                            <div class="card-name">
                                <h3><?php echo e($pro->name); ?></h3>
                            </div>
                            <div class="card-price">
                                <div class="price">
                                    <?php if($pro->price * $pro->discount == 0): ?>
                                    <h3 class="price-item"><?php echo e(number_format($pro->price)); ?> $</h3>
                                    <?php else: ?>
                                    <strike class="strike-discount"><?php echo e(number_format($pro->price)); ?> $</strike>
                                    <h3 class="price-item"><?php echo e(number_format($pro->price - (( $pro->price *
                                        $pro->discount)/100))); ?> $</h3>
                                    <?php endif; ?>
                                </div>
                                <div class="div">
                                    <h3 class="price-discount">Giảm <?php echo e($pro->discount); ?>%</h3>
                                </div>
                            </div>
                        </div>
                        <div class="card__bottom">
                            <input id="quantity" class="product_quantity_<?php echo e($pro->id); ?>" name="qty" type="hidden" min="1" value="1">
                            <input name="productid_hidden" type="hidden" value="<?php echo e($pro->id); ?>">
                            <button type="button" class="add-cart-ajax btn" data-id_product="<?php echo e($pro->id); ?>">
                                <i class="fas fa-shopping-cart"></i>
                                    Thêm vào giỏ
                            </button>
                        </div>
                    </div>                           
                  
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
    </section>  

    <span class="pagination justify-content-center mt-3"><?php echo e($products->links()); ?></span>  

</body>

<script>
    show_cart();
    function show_cart(){
        $.ajax({
            url:'<?php echo e(url('/show-cart')); ?>',
            method: "GET",
            success:function(data){
                $('.show-cart').html(data);
            }
        });
    } 
 
    //add-cart-ajax
    $(document).ready(function (){
        $('.add-cart-ajax').click(function(){
            var id = $(this).data('id_product');
            var product_id = $('.product_id_'+ id).val();
            var product_name = $('.product_name_'+ id).val();
            var product_image = $('.product_image_'+ id).val();
            var product_price = $('.product_price_'+ id).val();
            var product_quantity = $('.product_quantity_'+ id).val();
            var _token = $('input[name="_token"]').val();
        
            $.ajax({
                url: 'add-cart/',
                method: 'POST',
                data: { product_id:product_id,
                    product_name:product_name,
                    product_image:product_image,
                    product_price:product_price,
                    product_quantity:product_quantity,
                    _token:_token,
                },
                success:function(data){
                    swal("Good job!", "Thêm vào giỏ hàng thành công!", "success"); 
                    show_cart();            
                }
            });
        });
    });    
</script>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views//index.blade.php ENDPATH**/ ?>