<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 80px">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/home')); ?>">Trang chủ</a></li>
            <li class="breadcrumb-item active" aria-current="page">Giỏ hàng</li>
        </ol>
    </nav>
    <div class="table-reponsive cart_info">
        <?php
            $content = Cart::content()
        ?>
        <?php if(count($content)): ?>
        <table class="table table-condensed">
            <thead>
                <tr class="cart_menu">
                    <td class="image">Sản phẩm</td>
                    <td class="description">Tên sản phẩm</td>
                    <td class="price">Giá</td>
                    <td class="quantity">Số lượng</td>
                    <td class="total">Tổng</td>
                    <td>Xóa</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="cart_product">
                        <img src="<?php echo e(asset('/storage/image/'.$v_content->options->image)); ?>" height="150" width="150px">
                    </td>
                    <td class="cart_name">
                        <h4> <a href=""><?php echo e($v_content->name); ?></a> </h4>
                    </td>
                    <td class="cart_price">
                        <?php if($v_content->price * $v_content->discount == 0): ?>
                        <h6 class="card-title"><?php echo e(number_format($v_content->price)); ?> VNĐ</h6>
                        <?php else: ?>
                        <h6 class="card-title"><?php echo e(number_format($v_content->price - (( $v_content->price *
                            $pro->discount)/100))); ?> VNĐ</h6>
                        <?php endif; ?>
                    </td>
                    <td class="cart_quantity">
                        <div class="cart_quantity_button">
                            <form action="<?php echo e(URL::to('/update-cart')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input class="cart_quantity_input text-center" type="text" name="quantity"
                                    value="<?php echo e($v_content->qty); ?>" autocomplete="off" size="2">
                                <input type="hidden" value="<?php echo e($v_content->rowId); ?>" name="rowId_cart">
                                <input type="submit" value="Thay đổi">
                            </form>
                        </div>
                    </td>
                    <td class="total">
                        <p class="cart_total_price"><?php echo e(number_format($v_content->price * $v_content->qty)); ?> VNĐ</p>
                    </td>
                    <td class="cart_delete">
                        <a class="cart_quantity_delete" href="<?php echo e(URL::to('/delete-cart/'.$v_content->rowId)); ?>"><i
                                class="fa fa-times"></i>Xóa</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>    
    <div class="col-sm-3 float-right">        
        <div class="breadcrumb">
            <ul>
                <li class="breadcrumb">Thành tiền: <?php echo e(cart::subtotal(0).'VNĐ'); ?></li>
                <li class="breadcrumb">Phí vận chuyển: Free </li>
                <!-- <li class="breadcrumb">Tổng tiền: <?php echo e(cart::total(0).'VNĐ'); ?></li> -->
            </ul>
            <?php
                $customer_id = Session::get('customer_id');
                if($customer_id != null){
            ?>  
                <a href="<?php echo e(URL::to('/check-out')); ?>"><i class="fas fa-thumbs-up"></i></i> Thanh toán</a> 
            <?php
                }else{
            ?>
                <a href="<?php echo e(URL::to('/login')); ?>"><i class="fas fa-thumbs-up"></i></i> Thanh toán</a>
            <?php
                }
            ?>                    
        </div>
    <?php else: ?>
        <p>Bạn chưa có sản phẩm nào</p>      
    <?php endif; ?> 
    </div>      
</div>
<style>
    .cart_menu {
        background: linear-gradient(45deg, #40b2f5, #ffbc00);
        color: white;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/cart/index.blade.php ENDPATH**/ ?>