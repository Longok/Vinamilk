<?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8 mx-auto">
    <table class="table table-striped table-bordered mt-5 text-light">
    <h6>Liệt kê đơn hàng</h6>
    <thead>
            <tr class="text-center">
            <th scope="col-4" class="">STT</th>
                <th scope="col-4" class="">Tên khách hàng</th>
                <th scope="col-4" class="">Mã đơn hàng</th>
                <th scope="col-4" class="">Tình trạng </th>
                <th scope="col-4" class="">Sửa/Xóa</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $i = 0;
            ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $i++;
            ?>   
            <tr class="text-center">
                <td><?php echo e($i); ?></td>
                <td><?php echo e($order->Shipping->shipping_name); ?></td>
                <td><?php echo e($order->order_code); ?></td>
                <td>
                    <?php if($order->order_status == 1): ?>
                        Đơn hàng mới
                    <?php elseif($order->order_status == 2): ?>
                        Đã xử lý  
                    <?php else: ?>
                        Chưa xử lý                                          
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(URL::to('/view-order/'.$order->order_code)); ?>">Xem |</a>
                    <a href="<?php echo e(URL::to('/delete-order/'.$order->order_id)); ?>">Xóa</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/checkout/manage_order.blade.php ENDPATH**/ ?>