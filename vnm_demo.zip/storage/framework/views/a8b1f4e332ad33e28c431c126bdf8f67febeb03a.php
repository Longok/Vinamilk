<div class="footer mt-5">
  <div class="row">
    <div class="app col-lg-4 col-md-6 col-sm-6 col-xs-12 mt-2">
      <div class="footer-network ">
        <img src="https://www.vinamilk.com.vn/static/images/logo-vnm.png">
        <p>Tải ứng dụng di động
        <br>
        Giấc mơ sữa Việt</p>
      </div>
      <div class="footer-network ">
        <a target="_blank" href="https://appsto.re/vn/2t-lib.i"><img src="https://www.vinamilk.com.vn/static/images/download-ios.png"></a>
        <a target="_blank" href="https://play.google.com/store/apps/details?id=com.giacmosuaviet"><img src="https://www.vinamilk.com.vn/static/images/download-android.png"></a>
      </div>
    </div>
    <div class="link col-lg-4 col-md-6 col-sm-6 col-xs-12 d-flex text-center mt-3">
      <div class="div">
        <p>Mua ngay tại</p>
        <a href="">Giacmosuaviet.com </a>
      </div>
      <div class="div">
        <p>Kết nối với fanpage</p>
        <a href="https://www.facebook.com/vinamilkbiquyetngonkhoetuthiennhien/">Vinamilk tại đây</a>
      </div>
    </div>
    <div class="logo col-lg-4 col-md-6 col-sm-6 col-xs-12 mt-3">
      <a href="http://online.gov.vn/HomePage/CustomWebsiteDisplay.aspx?DocId=53194" target="_blank"><img alt="Vinamilk Bộ Công thương icon" src="https://www.vinamilk.com.vn/static/images/dathongbao.png"></a>
    </div>
  </div>
</div>

<?php /**PATH D:\Project\vnm_demo\resources\views/layout/footer.blade.php ENDPATH**/ ?>