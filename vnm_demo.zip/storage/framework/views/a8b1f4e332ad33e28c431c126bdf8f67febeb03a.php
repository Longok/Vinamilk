<div class="footer mt-3 mb-3">
  <!-- <div class="row">
    <div class="col col-third mt-3">
      <div class="footer-network ">
        <img src="https://www.vinamilk.com.vn/static/images/logo-vnm.png">
        <p>Tải ứng dụng di động
        <br>
        Giấc mơ sữa Việt</p>
      </div>
      <div class="footer-network ">
        <a target="_blank" href="https://appsto.re/vn/2t-lib.i"><img src="https://www.vinamilk.com.vn/static/images/download-ios.png"></a>
        <a target="_blank" href="https://play.google.com/store/apps/details?id=com.giacmosuaviet"><img src="https://www.vinamilk.com.vn/static/images/download-android.png"></a>
      </div>
    </div>
    <div class="col col-third d-flex mt-3">
      <div class="text-link">
        <div class="buy">
          <p>Mua ngay tại</p>
          <a href="">Giacmosuaviet.com </a>
        </div>
        <div class="fanpage">
          <p>Kết nối với fanpage</p>
          <a href="https://www.facebook.com/vinamilkbiquyetngonkhoetuthiennhien/">Vinamilk tại đây</a>
        </div>      
      </div>
    </div>
    <div class="col col-third mt-3">
      <a href="http://online.gov.vn/HomePage/CustomWebsiteDisplay.aspx?DocId=53194" target="_blank"><img alt="Vinamilk Bộ Công thương icon" src="https://www.vinamilk.com.vn/static/images/dathongbao.png"></a>
    </div>
  </div> -->
  <div class="row">
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mt-3">
      <img src="https://www.vinamilk.com.vn/static/images/logo-vnm.png">
        <p>Tải ứng dụng di động
          <br>
        Giấc mơ sữa Việt</p>
      <a target="_blank" href="https://appsto.re/vn/2t-lib.i"><img src="https://www.vinamilk.com.vn/static/images/download-ios.png"></a>
      <a target="_blank" href="https://play.google.com/store/apps/details?id=com.giacmosuaviet"><img src="https://www.vinamilk.com.vn/static/images/download-android.png"></a>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mt-3 ">
      <p>Mua ngay tại
        <br>
      <a href="#">Giacmosuaviet.com</a></p>
      <p>Kết nối với fanpage
        <br>
      <a href="https://www.facebook.com/vinamilkbiquyetngonkhoetuthiennhien/">Vinamilk tại đây</a></p>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mt-3">
      <a href="http://online.gov.vn/HomePage/CustomWebsiteDisplay.aspx?DocId=53194" target="_blank"><img alt="Vinamilk Bộ Công thương icon" src="https://www.vinamilk.com.vn/static/images/dathongbao.png"></a>
    </div>
  </div>
</div>

<?php /**PATH D:\Project\vnm_demo\resources\views/layout/footer.blade.php ENDPATH**/ ?>