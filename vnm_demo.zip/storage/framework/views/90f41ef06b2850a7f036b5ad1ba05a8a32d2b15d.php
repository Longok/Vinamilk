<?php echo $__env->make('layout.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content"> 
    <?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main">
           <div class="col-md-12">
            <section class="panel mt-3">
                <div class=" col-md-8 mx-auto">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="alert-danger">
                        <?php
                          $message = Session::get('Thongbao');
                          if($message){
                              echo '<span class="text-alert">'.$message.'</span>';
                              session::put('Thongbao',null);
                          }
                        ?>
                    </div>
                    <h2>
                        <a href="">Sửa sản phẩm</a>
                    </h2>       
                        <form action="<?php echo e(URL::to('/update-product/'.$products->id)); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <div class="form-group mt-3">
                                    <label class="info"> Tên sản phẩm</label>
                                    <input class="form-control" name="name" type="text" placeholder="<?php echo e($products->name); ?>">
                                </div>
                                <div class="form-group mt-3">
                                    <label class="info"> Mô tả sản phẩm</label>
                                    <input class="form-control" name="description" type="text" placeholder="<?php echo e($products->desc); ?>">
                                </div>
                                <div class="form-group mt-3">
                                    <label class="info"> Số lượng sản phẩm</label>
                                    <input class="form-control" name="quantity" type="text" placeholder="<?php echo e($products->quantity); ?>">
                                </div>
                                <div class="form-group mt-3">
                                    <label class="info"> Giá sản phẩm</label>
                                    <input class="form-control" name="price" type="text" placeholder="<?php echo e($products->price); ?>">
                                </div>
                                <div class="form-group">
                                    <label class="info"> Giảm giá sản phẩm</label>
                                    <select name="discount" class="form-control input-sm m-bot15" placeholder="<?php echo e($products->discount); ?>">
                                        <option value="0">0%</option>
                                        <option value="10">10%</option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="50">50%</option>
                                    </select>
                                </div>
                                <div class="form-group mt-3">
                                    <label class="info"> Hình ảnh sản phẩm</label>
                                    <input class="form-control" name="image" type="file" >
                                </div>
                                <div class="form-group mt-3">
                                    <label class="info"> Danh mục sản phẩm</label>
                                    <select name="category_id" class="form-control input-sm m-bot15">
                                        <option value="0">Chọn danh mục</option>
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-danger">Sửa sản phẩm</button>
                                </div>
                        </form>
                </div>
            </section>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<style>

    .main h2 a {
        text-decoration: none;
    }
    
    .info {
        font-size: 1.5rem;
    }

    select, option {
        font-size: 1.5rem;
    }
</style>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/products/edit.blade.php ENDPATH**/ ?>