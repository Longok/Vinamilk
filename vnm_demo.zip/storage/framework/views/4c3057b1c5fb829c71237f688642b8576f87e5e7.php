<?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8 mx-auto">
    <table class="table table-bordered mt-5 text-light">
        <thead>
            <tr class="text-center">
                <th scope="col-4" class="">#</th>
                <th scope="col-4" class="">Tên danh mục sản phẩm</th>
                <th scope="col-4" class="">Sửa/Xóa</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td scope="row"><?php echo e($category->id); ?></td>
                    <td scope="row"><a href="<?php echo e(URL::to('/list-product/'.$category->id)); ?>"><?php echo e($category->name); ?></a></td>
                    <td>
                        <a href="<?php echo e(URL::to('/edit-category/'.$category->id)); ?>">Sửa |</a>
                        <a href="<?php echo e(URL::to('/delete-category/'.$category->id)); ?>">Xóa</a>
                    </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/category/index.blade.php ENDPATH**/ ?>