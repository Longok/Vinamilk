<?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8 mx-auto">
    <table class="table table-bordered mt-5 text-primary">
        <thead>
            <tr class="text-center">
                <th scope="col-4" class="">#</th>
                <th scope="col-4" class="">Tên danh khách hàng</th>
                <th scope="col-4" class="">Email</th>
                <th scope="col-4" class="">Sửa/Xóa</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td scope="row"><?php echo e($customer->customer_id); ?></td>
                    <td scope="row"><?php echo e($customer->name); ?></td>
                    <td scope="row"><?php echo e($customer->email); ?></td>
                    <td>
                        <a href="<?php echo e(URL::to('/delete-customer/'.$customer->id)); ?>">Xóa</a>
                    </td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/customer/list.blade.php ENDPATH**/ ?>