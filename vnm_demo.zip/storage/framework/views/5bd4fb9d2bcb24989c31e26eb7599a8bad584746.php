<?php $__env->startSection('content'); ?>
<body>
<?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-md-8 col-xs-12 mx-auto">
        <div class="mt-3 text-light">
            <h6>Danh sách sản phẩm</h6>
        </div>
        <table class="table table-striped table-bordered mt-5 text-light">
            <thead>
                <tr class="text-center">
                    <th scope="col-4" class="">#</th>
                    <th scope="col-4" class="">Danh mục sản phẩm</th>
                    <th scope="col-4" class="">Tên sản phẩm</th>
                    <th scope="col-4" class="">Giá sản phẩm</th>
                    <th scope="col-4" class="">Hình ảnh sản phẩm</th>
                    <th scope="col-4" class="">Số lượng nhập vào</th>
                    <th scope="col-4" class="">Số lượng đã bán</th>
                    <th scope="col-4" class="">Giảm giá (%)</th>
                    <th scope="col-4" class="">Mô tả sản phẩm</th>
                    <th scope="col-4" class="">Sửa/Xóa</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td scope="row"><?php echo e($product->id); ?></td>
                    <td scope="row"><a href="<?php echo e(URL::to('/all-category')); ?>"><?php echo e($product->category->name); ?></a></td>
                    <td scope="row"><?php echo e($product->name); ?></td>
                    <td scope="row"><?php echo e($product->price); ?></td>
                    <td scope="row">
                        <img src="<?php echo e(asset('storage/image/'.$product->image)); ?>" height="150" width="150">
                    </td>
                    <td scope="row"><?php echo e($product->quantity); ?></td>
                    <td scope="row"><?php echo e($product->sale); ?></td>
                    <td scope="row"><?php echo e($product->discount); ?></td>
                    <td scope="row"><?php echo e($product->desc); ?></td>
                    <td>
                        <a href="<?php echo e(URL::to('/edit-product/'.$product->id)); ?>">Sửa</a>
                            |
                        <a href="<?php echo e(URL::to('/delete-product/'.$product->id)); ?>">Xóa</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <span class="pagination justify-content-center">
            <?php echo e($products->render()); ?>

        </span>
    </div> 
</body>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/products/index.blade.php ENDPATH**/ ?>