<?php echo $__env->make('layout.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content"> 
        <?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main">
            <div class="table-reponsive">
                <table class="table table-bordered mt-5 text-primary">
                    <thead>
                        <tr class="text-center">
                            <th scope="col-4" class="">#</th>
                            <th scope="col-4" class="">Title</th>
                            <th scope="col-4" class="">Description</th>
                            <!-- <th scope="col-4" class="">Content</th> -->
                            <th scope="col-4" class="">Image</th>
                            <th scope="col-4" class="">Sửa/Xóa</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td scope="row"><?php echo e($new->id); ?></td>
                                <td scope="row"><?php echo e($new->title); ?></td>
                                <td scope="row"><?php echo e($new->description); ?></td>
                                <!-- <td scope="row"><?php echo e($new->content); ?></td> -->
                                <td scope="row">
                                    <img src="<?php echo e(asset('/storage/image/'.$new->image)); ?>" height="160" width="100%">
                                </td>
                                <td>
                                    <a href="#">Xóa</a>|
                                    <a href="#">Sửa</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>   
    </div>

<?php $__env->stopSection(); ?>
<style>
    .text-center td {
        font-size: 1.3rem;
    }

    .text-center td a {
        margin: 0 auto;
    }
</style>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/news/list.blade.php ENDPATH**/ ?>