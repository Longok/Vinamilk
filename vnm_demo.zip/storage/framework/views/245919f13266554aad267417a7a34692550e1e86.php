<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<body>
    <div class="menu">
        <ul>
            <li class="active">
                <a href="<?php echo e(URL::to('/')); ?>">Trang chủ</a>
            </li>
            <li>
                <a href="">Sản phẩm
                    <i class="ti-angle-down"></i>  
                </a>
                <ul class="submenu">
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(URL::to('/category/'.$category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="">Tin tức</a></li>
            <li><a href="">Liên hệ</a></li>                   
        </ul> 
        <div class="search-btn">
            <form action="<?php echo e(URL::to('/search')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="keywords" placeholder="Tìm kiếm.." aria-label="Recipient's username">
                        <div class="input-group-append">
                            <span class="input-group-text"><i class="fa fa-search"></i></span>
                        </div>
                    </div>               
            </form>                        
        </div>      
    </div> 
    <div class="slide">
        <div id="demo" class="carousel " data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                    <li data-target="#demo" data-slide-to="1"></li>
                    <li data-target="#demo" data-slide-to="2"></li>
                </ul>
            <div class="carousel-inner col-12">
                <?php
                $i = 0;
                ?>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $i++;
                ?>
                <div class="carousel-item <?php echo e($i == 1 ? 'active' :''); ?>">
                    <img class="d-block " src="<?php echo e(asset('/storage/image/'.$slide->image)); ?>" width="100%" height="500">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>    
    </div> 
    <div class="content">
        <div class="container">            
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="box col-lg-3 col-md-6 col-sm-6 col-xs-12">
                    <form action="<?php echo e(Route('cart',$pro->id)); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="card">
                            <div class="d-flex justify-content-around mt-2">
                                <img src="<?php echo e(asset('/storage/image/'.$pro->image)); ?>" height="160" width="220px">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title "><?php echo e($pro->name); ?></h5>
                                <?php if($pro->price * $pro->discount == 0): ?>
                                <h6 class="card-title">Giá: <?php echo e(number_format($pro->price)); ?> VNĐ</h6>
                                <?php else: ?>
                                <strike class="card-title">Giá: <?php echo e(number_format($pro->price)); ?> vnđ</strike>
                                <h6 class="card-title">Giảm giá: <?php echo e(number_format($pro->price - (( $pro->price *
                                    $pro->discount)/100))); ?> VNĐ</h6>
                                <?php endif; ?>
                            </div>
                            <div class="quantity">
                                <h6>Số lượng</h6>
                                <input class="input" name="qty" type="number" min="1" value="1">
                                <input name="productid_hidden" type="hidden" value="<?php echo e($pro->id); ?>">
                                <button type="submit" class="btn btn-primary mb-2">Mua hàng</button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <span class="pagination justify-content-center"><?php echo e($products->render()); ?></span>
        </div>     
    </div>          
   
</body>
<script>
    $('.DM').click(function () {
        $(' ul.droplow').toggleClass("show");
    });
    $('.DM1').click(function () {
         $(' ul.droplow1').toggleClass("show1");
    });
    $('.DM2').click(function () {
        $(' ul.droplow2').toggleClass("show2");
    });
    $('.DM3').click(function () {
         $(' ul.droplow3').toggleClass("show3");
    });
    $('.DM4').click(function () {
         $(' ul.droplow4').toggleClass("show4");
    });
    $('.icon').click(function () {
       alert('helo');
    });
</script>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/index.blade.php ENDPATH**/ ?>