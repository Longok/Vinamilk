<?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>       
<div class="col-md-8 mx-auto">
<h1>Chi tiết đơn hàng</h1>
    <table class="table table-striped table-bordered mt-5 text-light">
        <tbody>
            <tr>
                <td>Tên người đặt hàng</td>
                <td><?php echo e($customer->name); ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo e($shipping->shipping_email); ?></td>
            </tr>
            <tr>
                <td>Số điện thoại</td>
                <td><?php echo e($shipping->shipping_phone); ?></td>
            </tr>
            <tr>
                <td>Địa chỉ</td>
                <td><?php echo e($shipping->shipping_adress); ?></td>
            </tr>
            <tr>
                <td>Ngày đặt hàng</td>
                <td><?php echo e($shipping->created_at); ?></td>
            </tr>                                
            <tr>
                <td>Hình thức thanh toán</td>
                <td><?php echo e($shipping->shipping_method); ?></td>
            </tr>
            <tr>
                <td>Ghi chú</td>
                <td><?php echo e($shipping->shipping_note); ?></td>
            </tr>
        </tbody>
    </table>
    <table class="table table-striped table-bordered mt-4 text-light">
        <thead>
            <tr role="row">
                <th>STT</th>
                <th>Tên sản phẩm</th>
                <th>Hình ảnh sản phẩm</th>
                <th>Tồn kho</th>
                <th>Số lượng</th>
                <th>Đơn giá (vnđ)</th>
            </tr>    
        </thead>
        <tbody> 
            <?php
                $i = 0;
            ?>
        <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $i++;
            ?>          
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($detail->product_name); ?></td>
                    <td>
                        <img src="<?php echo e(asset('storage/image/'.$detail->product->image)); ?>" height="100" width="150">
                    </td>
                    <td><?php echo e($detail->product->quantity); ?></td>
                    <td>
                        <input type="number" min="1" value="<?php echo e($detail->product_quantity); ?>" name="product_quantity">
                        <input type="hidden" value="<?php echo e($detail->product_id); ?>" name="order_product_id" class="order_product_id">
                        <button class="btn btn-success btn-sm" name="update_quantity">Cập nhật</button>
                    </td>
                    <td><?php echo e(number_format($detail->product_price ,0,'.','.')); ?></td>
                </tr>               
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="3"><b>Tổng tiền</b></td>
                    <td colspan="1"><b class="text-red"><?php echo e(number_format($detail->product_quantity*$detail->product_price ,0,'.','.')); ?> vnđ</b></td>
                </tr>      
        </tbody>
    </table>               
    <div class="col-md-12 mt-3">
        <label>Tình trạng đơn hàng: </label>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
            <?php if($order->order_status ==1): ?>
            <form method="POST">
            <?php echo e(csrf_field()); ?>          
                <div class="form-inline">                
                    <select name="order_status" class="form-control input-inline update_order_status" style="width: 200px">
                        <option id="<?php echo e($order->order_id); ?>" selected value="1">Đang xử lý</option>
                        <option id="<?php echo e($order->order_id); ?>" value="2">Đã xử lý</option>
                        <option id="<?php echo e($order->order_id); ?>" value="3">Chưa xử lý</option>
                    </select>
                </div>
            </form>
            <?php elseif($order->order_status ==2): ?>
            <form method="POST">
            <?php echo e(csrf_field()); ?>          
                <div class="form-inline">                
                    <select name="order_status" class="form-control input-inline update_order_status" style="width: 200px">
                        <option id="<?php echo e($order->order_id); ?>" value="1">Đang xử lý</option>
                        <option id="<?php echo e($order->order_id); ?>" selected value="2">Đã xử lý</option>
                        <option id="<?php echo e($order->order_id); ?>" value="3">Chưa xử lý</option>
                    </select>
                </div>
            </form>
            <?php else: ?>
            <form method="POST">
            <?php echo e(csrf_field()); ?>          
                <div class="form-inline">                
                    <select name="order_status" class="form-control input-inline update_order_status" style="width: 200px">
                        <option id="<?php echo e($order->order_id); ?>" value="1">Đang xử lý</option>
                        <option id="<?php echo e($order->order_id); ?>" value="2">Đã xử lý</option>
                        <option id="<?php echo e($order->order_id); ?>" selected value="3">Chưa xử lý</option>
                    </select>
                </div>
            </form>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script>
    $('.update_order_status').change(function(){
        var order_status = $(this).val();
        // alert(order_status);
        var order_id = $(this).children(":selected").attr("id");
        // alert(order_id);
        var _token = $('input[name="_token"]').val();
        // alert(_token);
        //lấy số lượng
        quantity = [];
        $('input[name="product_quantity"]').each(function(){
            quantity.push($(this).val());
        });
        // alert(quantity);
        //lấy product id
        order_product_id = [];
        $('input[name="order_product_id"]').each(function(){
            order_product_id.push($(this).val());
        });
        // alert(order_product_id);
        $.ajax({
                url:'<?php echo e(url('/update-order-status')); ?>',
                method: 'POST',
                data:{order_status:order_status,order_id:order_id,_token:_token,quantity:quantity,order_product_id:order_product_id},
                success:function(data){
                    alert('Cập nhật tình trạng đơn hàng thành công');   
                    // location.reload();
            }
        });
    });
  </script>                  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/checkout/view_order.blade.php ENDPATH**/ ?>