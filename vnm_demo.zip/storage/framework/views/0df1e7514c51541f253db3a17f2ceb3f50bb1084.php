<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    
    <div class="slide">
        <div id="demo" class="carousel " data-ride="carousel">
            <ul class="carousel-indicators">
                <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                <li data-target="#demo" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner">
                <?php
                $i = 0;
                ?>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $i++;
                ?>
                <div class="carousel-item <?php echo e($i == 1 ? 'active' :''); ?>">
                    <img src="<?php echo e(asset('/storage/image/'.$slide->image)); ?>" width="100%">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
        </div>
    </div>
    </div>
    <div class="content bg-light mt-2">
        <div class="container">
            <div class=" col-md-10 col-xs-12 mt-4 news ">                   
                <h1><?php echo e($news->title); ?></h1>
                   
                <img src="<?php echo e(asset('/storage/image/'.$news->image)); ?>" height="100%" width="100%">
                  
                <h4 class="mt-4 "><?php echo e($news->description); ?></a></h4>

                <h4 class="text-secondary"><?php echo $news->content; ?></h4>        
            </div>           
        </div>    
        <div class="">
                <h3 class="text-dark mt-5 text-center">Bài viết liên quan</h3>
                <ul class="list-news">
                    <?php $__currentLoopData = $list_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(URL::to('/news-detail/'.$news->id)); ?>"><li><?php echo e($news->title); ?></li></a>                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
        </div> 
    </div>
</body>
<script>
    var menu = document.getElementById('menu');
    var menuIcon = document.getElementById('menu-icon');
    var menuHeight = menu.clientHeight;

    menuIcon.onclick = function () {
        var closeIcon = menu.clientHeight === menuHeight;
        if (closeIcon) {
            menu.style.height = 'auto';
        } else {
            menu.style.height = null;
        }
    }
</script>
<style>
body{
    background-color: whitesmoke;
    padding: 0;
    margin:0;
    box-sizing: border-box;
}  

.container h1 {
    margin: 2rem 0;
    padding: 2rem 0;
    text-align: center;
}
.news {
    color: #000;
    margin: auto;
    min-height: 300px;
}
.list-news {
    margin-left: 25%;
    display: flex;
    flex-direction: column;
    align-items: start;
}

.list-news > a {
    font-size: 1.5rem;
    margin-top: 1rem;
}

@media (min-width: 740px) and (max-width:1023px) {
    .list-news {
    margin-left: 10%;
    display: flex;
    flex-direction: column;
    align-items: start;
    }
}
  
@media (max-width: 740px) {
    .list-news {
    margin-left: 10%;
    display: flex;
    flex-direction: column;
    align-items: start;
    }
}
</style>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/news/detail.blade.php ENDPATH**/ ?>