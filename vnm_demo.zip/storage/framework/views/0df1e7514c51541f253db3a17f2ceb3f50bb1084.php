<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div id="menu">
        <ul>
            <li class="active">
                <a href="<?php echo e(URL::to('/index')); ?>">Trang chủ</a>
            </li>
            <li>
                <a href="#">Sản phẩm
                    <i class="ti-angle-down"></i>
                </a>
                <ul class="submenu">
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(URL::to('/category/'.$category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="<?php echo e(URL::to('/news')); ?>">Tin tức</a></li>
            <li><a href="#">Liên hệ</a></li>
        </ul>
        <div class="search-btn">
            <form action="<?php echo e(URL::to('/search')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="keywords" placeholder="Tìm kiếm.."
                        aria-label="Recipient's username">
                    <div class="input-group-append">
                        <span class="input-group-text"><i class="fa fa-search"></i></span>
                    </div>
                </div>
            </form>
        </div>
        <div id="menu-icon" class="menu-icon">
            <i class="ti-align-justify"></i>
        </div>
    </div>
    <div class="slide">
        <div id="demo" class="carousel " data-ride="carousel">
            <ul class="carousel-indicators">
                <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                <li data-target="#demo" data-slide-to="2"></li>
            </ul>
            <div class="carousel-inner">
                <?php
                $i = 0;
                ?>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $i++;
                ?>
                <div class="carousel-item <?php echo e($i == 1 ? 'active' :''); ?>">
                    <img src="<?php echo e(asset('/storage/image/'.$slide->image)); ?>" width="100%">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
        </div>
    </div>
    </div>
    <div class="content bg-light mt-2">
        <div class="container">
            <div class=" col-8 mt-4 news ">                   
                <h5 class=" "><?php echo e($news->title); ?></h5>
                   
                <img src="<?php echo e(asset('/storage/image/'.$news->image)); ?>" height="100%" width="100%">
                  
                <h6 class=" mt-4 "><?php echo e($news->description); ?></a></h6>

                <h6><?php echo $news->content; ?></h6>        
            </div>           
        </div>    
        <div class="">
                <h4 class="text-warning mt-5 text-center">Bài viết liên quan</h4>
                <ul class="list-news col-5">
                    <?php $__currentLoopData = $list_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(URL::to('/news-detail/'.$news->id)); ?>"><li><?php echo e($news->title); ?></li></a>                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
        </div> 
    </div>
</body>
<script>
    var menu = document.getElementById('menu');
    var menuIcon = document.getElementById('menu-icon');
    var menuHeight = menu.clientHeight;

    menuIcon.onclick = function () {
        var closeIcon = menu.clientHeight === menuHeight;
        if (closeIcon) {
            menu.style.height = 'auto';
        } else {
            menu.style.height = null;
        }
    }
</script>
<style>
body{
    background-color: whitesmoke;
     padding: 0;
    margin:0;
    box-sizing: border-box;
}    
.news {
    /* border: 2px solid black ; */
    color: #000;
    margin: auto;
    min-height: 300px;
}
.list-news {
    margin: auto;

}

</style>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/news/detail.blade.php ENDPATH**/ ?>