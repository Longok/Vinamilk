<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 80px">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/index')); ?>">Trang chủ</a></li>
        </ol>
    </nav>
    <div class="div">
        <h5>Cảm ơn bạn đã đặt hàng, chúng tôi sẽ giao hàng sớm nhất !!</h5>
    </div>
</div>
<style>
    .cart_menu {
        background: linear-gradient(45deg, #40b2f5, #ffbc00);
        color: white;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/checkout/message.blade.php ENDPATH**/ ?>