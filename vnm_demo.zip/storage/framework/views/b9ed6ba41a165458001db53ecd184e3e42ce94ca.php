<?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
   <div class="container">
       <div class="row">
           <div class="col-md-12">
            <section class="panel mt-3">
                <div class=" col-md-8 mx-auto">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="alert-danger">
                        <?php
                          $message = Session::get('Thongbao');
                          if($message){
                              echo '<span class="text-alert">'.$message.'</span>';
                              session::put('Thongbao',null);
                          }
                        ?>
                    </div>
                    <div class="mt-4">
                        <a href="">Thêm Slide</a>
                    </div>
                        <form action="<?php echo e(URL::to('add-slide')); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <div class="form-group mt-3">
                                    <label for="">Tên Slide</label>
                                    <input class="form-control" name="name" type="text">
                                </div>
                                <div class="form-group mt-3">
                                    <label for="">Mô tả Slide</label>
                                    <input class="form-control" name="description" type="text">
                                </div>

                                <div class="form-group mt-3">
                                    <label for="">Hình ảnh Slide</label>
                                    <input class="form-control" name="image" type="file">
                                </div>

                                <div class="form-group mt-3">
                                    <button type="submit" class="btn btn-danger">Thêm Slide</button>
                                </div>
                        </form>
                </div>
            </section>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/slide/create.blade.php ENDPATH**/ ?>