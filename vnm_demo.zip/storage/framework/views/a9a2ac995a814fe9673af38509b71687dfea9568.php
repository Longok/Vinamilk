<?php echo $__env->make('layout.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content"> 
    <?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main">

        <h2>
            <a href="">Danh sách Slide</a>
        </h2>

        <div class="table-reponsive">
        <table class="table table-bordered mt-5">
            <thead>
                <tr class="text-center">
                    <th scope="col-4" class="">#</th>
                    <th scope="col-4" class="">Tên sản phẩm</th>
                    <th scope="col-4" class="">Hình ảnh sản phẩm</th>
                    <th scope="col-4" class="">Mô tả sản phẩm</th>
                    <th scope="col-4" class="">Sửa/Xóa</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td scope="row"><?php echo e($sli->id); ?></td>
                    <td scope="row"><?php echo e($sli->name); ?></td>
                    <td scope="row">
                        <img src="<?php echo e(asset('storage/image/'.$sli->image)); ?>" height="150" width="450">
                    </td>
                    <td scope="row"><?php echo e($sli->description); ?></td>
                    <td>
                        <a href="<?php echo e(URL::to('/edit-slide/'.$sli->id)); ?>">Sửa</a>
                        |
                        <a href="<?php echo e(URL::to('/delete-slide/'.$sli->id)); ?>">Xóa</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<style>

    .main h2 a {
        text-decoration: none;
    }

    .text-center td {
        font-size: 1.5rem;
    }
    
    .text-center td a {
        margin: 0 auto;
    }
</style>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/slide/index.blade.php ENDPATH**/ ?>