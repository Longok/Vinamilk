<?php echo $__env->make('layout.headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8 mx-auto">
        <div class="mt-3 text-light">
            <h6>Danh sách Slide</h6>
        </div>
        <table class="table table-bordered mt-5 text-light">
            <thead>
                <tr class="text-center">
                    <th scope="col-4" class="">#</th>
                    <th scope="col-4" class="">Tên sản phẩm</th>
                    <th scope="col-4" class="">Hình ảnh sản phẩm</th>
                    <th scope="col-4" class="">Mô tả sản phẩm</th>
                    <th scope="col-4" class="">Sửa/Xóa</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td scope="row"><?php echo e($sli->id); ?></td>
                    <td scope="row"><?php echo e($sli->name); ?></td>
                    <td scope="row">
                        <img src="<?php echo e(asset('storage/image/'.$sli->image)); ?>" height="200" width="200">
                    </td>
                    <td scope="row"><?php echo e($sli->description); ?></td>
                    <td>
                        <a href="<?php echo e(URL::to('/edit-slide/'.$sli->id)); ?>">Sửa</a>
                        |
                        <a href="<?php echo e(URL::to('/delete-slide/'.$sli->id)); ?>">Xóa</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\vnm_demo\resources\views/slide/index.blade.php ENDPATH**/ ?>